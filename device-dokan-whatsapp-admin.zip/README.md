# Device Dokan – WhatsApp Order + Admin Panel

## Files
- `index.html` – storefront with dynamic products and WhatsApp Order Now
- `admin.html` – mobile-friendly Admin Panel
- `logo.png` – existing Device Dokan logo

## Admin login
Username: `admin`
Password: `DeviceDokan@2026`

## WhatsApp
Orders go to: `+8801336056864`

## Important
This initial version stores products in the browser's localStorage. It is useful for testing and a single-browser setup, but it is NOT a shared production database.

For a production setup where products added from any phone appear on every customer's device, connect Firebase or Supabase. The current UI and WhatsApp flow are ready to be connected to that backend.
